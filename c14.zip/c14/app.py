import discord
import os

client = discord.Client()

@client.event
async def on_ready():
    print(client.user)

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content == "Hello":
        
        message.channel.send(f"Hello ,{message.author}")
    
    if message.content == "Dog Pic":
        
        message.channel.send(f"This Function havn't developed")

client.run(os.getenv("token"))